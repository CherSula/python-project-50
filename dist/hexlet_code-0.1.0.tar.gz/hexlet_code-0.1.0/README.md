### Hexlet tests and linter status:
[![Actions Status](https://github.com/CherSula/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/CherSula/python-project-50/actions)
### Ascinemas:
[![asciicast](https://asciinema.org/a/XzndWWfvsjEycD0ADafsr5zNz.svg)](https://asciinema.org/a/XzndWWfvsjEycD0ADafsr5zNz)
### CodeClimate:
[![Maintainability](https://api.codeclimate.com/v1/badges/22eaee8f1739869c2d9e/maintainability)](https://codeclimate.com/github/CherSula/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/22eaee8f1739869c2d9e/test_coverage)](https://codeclimate.com/github/CherSula/python-project-50/test_coverage)